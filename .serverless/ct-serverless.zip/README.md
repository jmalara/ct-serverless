# CT-serverless
CT Assessment - Serverless
